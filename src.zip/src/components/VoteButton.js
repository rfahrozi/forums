import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { upvoteThread, downvoteThread } from '../redux/slices/votesSlice';

// Komponen tombol vote thread
export default function VoteButton({ threadId }) {
  const dispatch = useDispatch();
  const token = useSelector(state => state.auth.token);
  const voteStatus = useSelector(state => state.votes.threadVotes[threadId]); // 'up', 'down', undefined

  function handleUpvote() {
    if (!token) {
      alert('Harap login dahulu untuk upvote!');
      return;
    }
    dispatch(upvoteThread({ threadId, token }));
  }
  function handleDownvote() {
    if (!token) {
      alert('Harap login dahulu untuk downvote!');
      return;
    }
    dispatch(downvoteThread({ threadId, token }));
  }

  return (
    <div>
      <button
        style={{ color: voteStatus === 'up' ? 'red' : 'grey', marginRight: 6 }}
        onClick={handleUpvote}>↑ Upvote</button>
      <button
        style={{ color: voteStatus === 'down' ? 'blue' : 'grey' }}
        onClick={handleDownvote}>↓ Downvote</button>
      {/* Komentar: Tombol warna sesuai status vote, human-friendly UX */}
    </div>
  );
}
