import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { registerApi, loginApi } from '../../api/forumApi';

// Async thunk untuk register dan login
export const registerUser = createAsyncThunk('auth/register', registerApi);
export const loginUser = createAsyncThunk('auth/login', loginApi);

const initialState = { user: null, token: null, status: 'idle', error: null };

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout(state) {
      state.user = null;
      state.token = null;
      localStorage.removeItem('accessToken');
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerUser.fulfilled, (state, action) => {
        state.user = action.payload;
        state.status = 'succeeded';
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.token = action.payload.token;
        state.status = 'succeeded';
        localStorage.setItem('accessToken', action.payload.token);
      });
  },
});
export const { logout } = authSlice.actions;
export default authSlice.reducer;
