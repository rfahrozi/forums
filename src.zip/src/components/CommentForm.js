import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { postComment } from '../redux/slices/commentSlice';

// Komponen form komentar pada thread
export default function CommentForm({ threadId }) {
  const [content, setContent] = useState('');
  const dispatch = useDispatch();
  const token = useSelector(state => state.auth.token);

  function handleSubmit(e) {
    e.preventDefault();
    if (!token) {
      alert('Harap login dahulu untuk berkomentar!');
      return;
    }
    dispatch(postComment({ threadId, content }));
    setContent('');
  }

  return (
    <form onSubmit={handleSubmit} style={{ margin: '16px 0' }}>
      <textarea
        placeholder="Tulis komentar..."
        required
        value={content}
        onChange={e => setContent(e.target.value)}
        style={{ width: 300, height: 60 }}
      />
      <button type="submit">Kirim</button>
    </form>
  );
}
