import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { getThreads, createThread, getThreadDetail } from '../../api/forumApi';

export const fetchThreads = createAsyncThunk('threads/list', getThreads);
export const postThread = createAsyncThunk(
  'threads/post',
  async (payload, thunkAPI) => {
    const { token } = thunkAPI.getState().auth;
    return createThread(payload, token);
  },
);
export const fetchThreadDetail = createAsyncThunk(
  'threads/detail',
  getThreadDetail,
);

const threadSlice = createSlice({
  name: 'threads',
  initialState: { list: [], detail: null, status: 'idle', error: null },
  extraReducers: (builder) => {
    builder
      .addCase(fetchThreads.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchThreads.fulfilled, (state, action) => {
        state.list = action.payload;
        state.status = 'succeeded';
        state.error = null;
      })
      .addCase(fetchThreads.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(postThread.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(postThread.fulfilled, (state, action) => {
        state.list.unshift(action.payload);
        state.status = 'succeeded';
        state.error = null;
      })
      .addCase(postThread.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(fetchThreadDetail.fulfilled, (state, action) => {
        state.detail = action.payload;
      });
  },
});
export default threadSlice.reducer;
