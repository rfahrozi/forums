import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { registerUser, loginUser } from '../redux/slices/authSlice';

// Komponen form register dan login
export default function AuthForm({ mode = 'login' }) {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const dispatch = useDispatch();

  function handleSubmit(e) {
    e.preventDefault();
    if (mode === 'register') {
      dispatch(registerUser(form));
    } else {
      dispatch(loginUser(form));
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>{mode === 'register' ? 'Daftar Akun' : 'Login'}</h2>
      {mode === 'register' &&
        <input type="text" placeholder="Nama" required value={form.name}
               onChange={e => setForm({ ...form, name: e.target.value })} />}
      <input type="email" required placeholder="Email" value={form.email}
             onChange={e => setForm({ ...form, email: e.target.value })} />
      <input type="password" required placeholder="Password" value={form.password}
             onChange={e => setForm({ ...form, password: e.target.value })} />
      <button type="submit">{mode === 'register' ? 'Daftar' : 'Login'}</button>
    </form>
  );
}
