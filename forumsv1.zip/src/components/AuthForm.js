import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import { registerUser, loginUser } from '../redux/slices/authSlice';

// Komponen form register dan login
function AuthForm({ mode }) {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const dispatch = useDispatch();
  const { status, error } = useSelector((state) => state.auth);

  let buttonText = 'Login';
  if (status === 'loading') buttonText = 'Loading...';
  else if (mode === 'register') buttonText = 'Daftar';

  function handleSubmit(e) {
    e.preventDefault();
    if (mode === 'register') {
      dispatch(registerUser(form));
    } else {
      dispatch(loginUser(form));
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>{mode === 'register' ? 'Daftar Akun' : 'Login'}</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {mode === 'register' && (
        <input
          type="text"
          placeholder="Nama"
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
      )}
      <input
        type="email"
        required
        placeholder="Email"
        value={form.email}
        onChange={(e) => setForm({ ...form, email: e.target.value })}
      />
      <input
        type="password"
        required
        placeholder="Password"
        value={form.password}
        onChange={(e) => setForm({ ...form, password: e.target.value })}
      />
      <button type="submit" disabled={status === 'loading'}>
        {buttonText}
      </button>
    </form>
  );
}

AuthForm.propTypes = { mode: PropTypes.string };

AuthForm.defaultProps = { mode: 'login' };

export default AuthForm;
