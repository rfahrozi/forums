import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import AuthForm from './components/AuthForm';
import ThreadList from './components/ThreadList';
import ThreadForm from './components/ThreadForm';
import Leaderboard from './components/Leaderboard';
import LoadingIndicator from './components/LoadingIndicator';
import ThreadDetailPage from './pages/ThreadDetailPage';
// ...
<Route path="/threads/:threadId" element={<ThreadDetailPage />} />
import { Link } from 'react-router-dom';
// ...
<Link to={`/threads/${thread.id}`}>{thread.title}</Link>

// Untuk logout
import { logout } from './redux/slices/authSlice';
import './styles/App.css';

// Komponen home page utama
function Home() {
  const token = useSelector(state => state.auth.token);
  return (
    <div>
      <ThreadForm />
      <ThreadList />
    </div>
  );
}

// Komponen login dan register secara terpisah
function RegisterPage() { return <AuthForm mode='register' />; }
function LoginPage()    { return <AuthForm mode='login' />; }

export default function App() {
  const token = useSelector(state => state.auth.token);
  const dispatch = useDispatch();

  return (
    <Router>
      <nav style={{ padding: 10, marginBottom: 16, background: '#f3f7fa', borderBottom: '1px solid #bbb' }}>
        <Link to="/">Beranda</Link> |{" "}
        <Link to="/leaderboard">Leaderboard</Link> |{" "}
        {!token ? (
          <>
            <Link to="/register">Daftar</Link> |{" "}
            <Link to="/login">Login</Link>
          </>
        ) : (
          <button onClick={() => dispatch(logout())} style={{ color: '#d44', background: 'none', border: 'none', cursor: 'pointer' }}>Logout</button>
        )}
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={!token ? <RegisterPage /> : <Navigate to="/" />} />
        <Route path="/login" element={!token ? <LoginPage /> : <Navigate to="/" />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="*" element={<div>Halaman tidak ditemukan</div>} />
      </Routes>
    </Router>
  );
}
