import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setCategory } from '../redux/slices/categorySlice';

const kategoriList = ['Semua', 'React', 'Redux', 'Javascript', 'General'];

export default function CategoryFilter() {
  const dispatch = useDispatch();
  const selected = useSelector(state => state.category.selected);

  return (
    <div style={{ margin: "10px 0" }}>
      <span>Pilih kategori: </span>
      {kategoriList.map(cat => (
        <button
          key={cat}
          onClick={() => dispatch(setCategory(cat))}
          style={{
            fontWeight: selected === cat ? 'bold' : 'normal',
            background: selected === cat ? '#cce' : '#eee',
            marginRight: 6,
          }}>{cat}</button>
      ))}
    </div>
  );
}
