import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { voteThreadUp, voteThreadDown } from '../../api/forumApi';

// AsyncThunk untuk voting thread
export const upvoteThread = createAsyncThunk(
  'votes/up',
  async ({ threadId, token }) => voteThreadUp(threadId, token),
);

export const downvoteThread = createAsyncThunk(
  'votes/down',
  async ({ threadId, token }) => voteThreadDown(threadId, token),
);

const votesSlice = createSlice({
  name: 'votes',
  initialState: { threadVotes: {} }, // { [threadId]: 'up'|'down'|undefined }
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(upvoteThread.fulfilled, (state, action) => {
        const { threadId } = action.meta.arg;
        state.threadVotes[threadId] = 'up';
      })
      .addCase(downvoteThread.fulfilled, (state, action) => {
        const { threadId } = action.meta.arg;
        state.threadVotes[threadId] = 'down';
      });
  },
});

export default votesSlice.reducer;
