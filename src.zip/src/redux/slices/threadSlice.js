import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { getThreads, createThread, getThreadDetail } from '../../api/forumApi';

export const fetchThreads = createAsyncThunk('threads/list', getThreads);
export const postThread = createAsyncThunk('threads/post', async (payload, thunkAPI) => {
  const token = thunkAPI.getState().auth.token;
  return await createThread(payload, token);
});
export const fetchThreadDetail = createAsyncThunk('threads/detail', getThreadDetail);

const threadSlice = createSlice({
  name: 'threads',
  initialState: { list: [], detail: null, status: 'idle', error: null },
  extraReducers: (builder) => {
    builder
      .addCase(fetchThreads.pending, (state) => { state.status = 'loading'; })
      .addCase(fetchThreads.fulfilled, (state, action) => {
        state.list = action.payload;
        state.status = 'succeeded';
      })
      .addCase(postThread.fulfilled, (state, action) => {
        state.list.unshift(action.payload);
      })
      .addCase(fetchThreadDetail.fulfilled, (state, action) => {
        state.detail = action.payload;
      });
  }
});
export default threadSlice.reducer;
