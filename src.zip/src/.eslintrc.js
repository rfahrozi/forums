module.exports = {
  extends: ['airbnb', 'eslint:recommended', 'plugin:react/recommended'],
  env: { browser: true, node: true, es6: true },
  rules: {
    'react/jsx-filename-extension': [1, { extensions: ['.js', '.jsx'] }],
    // Tambahkan custom rules jika perlu
  },
};
