export default function LoadingIndicator() {
  return <div style={{ color: '#389' }}>⏳ Loading ...</div>;
}
