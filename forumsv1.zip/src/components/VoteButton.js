import React from 'react';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import { upvoteThread, downvoteThread } from '../redux/slices/votesSlice';

// Komponen tombol vote thread
function VoteButton({ threadId }) {
  const dispatch = useDispatch();
  const token = useSelector((state) => state.auth.token);
  const voteStatus = useSelector((state) => state.votes.threadVotes[threadId]);

  function handleUpvote() {
    if (!token) {
      console.warn('Harap login dahulu untuk upvote!');
      return;
    }
    dispatch(upvoteThread({ threadId, token }));
  }
  function handleDownvote() {
    if (!token) {
      console.warn('Harap login dahulu untuk downvote!');
      return;
    }
    dispatch(downvoteThread({ threadId, token }));
  }

  return (
    <div>
      <button
        type="button"
        style={{ color: voteStatus === 'up' ? 'red' : 'grey', marginRight: 6 }}
        onClick={handleUpvote}
      >
        ↑ Upvote
      </button>
      <button
        type="button"
        style={{ color: voteStatus === 'down' ? 'blue' : 'grey' }}
        onClick={handleDownvote}
      >
        ↓ Downvote
      </button>
      {/* Komentar: Tombol warna sesuai status vote, human-friendly UX */}
    </div>
  );
}

VoteButton.propTypes = { threadId: PropTypes.string.isRequired };

export default VoteButton;
