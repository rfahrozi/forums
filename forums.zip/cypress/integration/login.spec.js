describe('Login Flow', () => {
  it('should allow user to login successfully', () => {
    // Mengunjungi halaman login
    cy.visit('http://localhost:3000/login');

    // Memastikan halaman login dimuat
    cy.contains('Login').should('be.visible');

    // Mengisi form login
    cy.get('input[placeholder="Email"]').type('fahrozi@gmail.com');
    cy.get('input[placeholder="Password"]').type('rafa1234');

    // Mengklik tombol login
    cy.get('button[type="submit"]').click();

    // Memastikan redirect ke halaman home setelah login berhasil
    cy.url().should('include', '/');

    // Memastikan navigasi menampilkan logout
    cy.contains('Logout').should('be.visible');
  });

  it('should show error on invalid login', () => {
    cy.visit('http://localhost:3000/login');

    cy.get('input[placeholder="Email"]').type('fahrozi@gmail.com');
    cy.get('input[placeholder="Password"]').type('wrongpassword');

    cy.get('button[type="submit"]').click();

    // Asumsi error message ditampilkan
    cy.contains('Login failed').should('be.visible');
  });
});
