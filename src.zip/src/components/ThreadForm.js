import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { postThread } from '../redux/slices/threadSlice';

// Komponen form untuk membuat thread baru
export default function ThreadForm() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const dispatch = useDispatch();
  const token = useSelector(state => state.auth.token);

  function handleSubmit(e) {
    e.preventDefault();
    if (!token) {
      alert('Harap login dahulu untuk membuat thread!');
      return;
    }
    dispatch(postThread({ title, body }));
    setTitle(''); setBody('');
  }

  return (
    <form onSubmit={handleSubmit} style={{ margin: '16px 0' }}>
      <h3>Buat Thread Baru</h3>
      <input
        placeholder="Judul"
        required
        value={title}
        onChange={e => setTitle(e.target.value)}
        style={{ display: 'block', width: 300 }}
      />
      <textarea
        placeholder="Isi thread"
        required
        value={body}
        onChange={e => setBody(e.target.value)}
        style={{ display: 'block', width: 300, height: 70 }}
      />
      <button type="submit">Posting Thread</button>
    </form>
  );
}
