import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchThreads } from '../redux/slices/threadSlice';
import VoteButton from './VoteButton';
import CategoryFilter from './CategoryFilter';
import LoadingIndicator from './LoadingIndicator';

export default function ThreadList() {
  const dispatch = useDispatch();
  const threads = useSelector((state) => state.threads.list);
  const status = useSelector((state) => state.threads.status);
  const selectedCategory = useSelector((state) => state.category.selected);

  useEffect(() => {
    dispatch(fetchThreads());
  }, [dispatch]);

  // Filtering kategori (asumsi kategori = property di thread, contoh: thread.category)
  const filtered = selectedCategory === 'Semua'
    ? threads
    : threads.filter((t) => t.category === selectedCategory);

  if (status === 'loading') return <LoadingIndicator />;

  return (
    <div>
      <CategoryFilter />
      <h2>Daftar Thread</h2>
      {filtered.length === 0 ? <p>Belum ada thread di kategori ini</p> : null}
      {filtered.map((thread) => (
        <div
          key={thread.id}
          style={{ border: '1px solid #ccc', margin: 8, padding: 8 }}
        >
          <h4>{thread.title}</h4>
          <p>
            {thread.body.slice(0, 60)}
            ...
          </p>
          <div>
            Oleh:
            {' '}
            {thread.ownerName}
            {' '}
            |
            {' '}
            {new Date(thread.createdAt).toLocaleString()}
          </div>
          <VoteButton threadId={thread.id} />
        </div>
      ))}
    </div>
  );
}
