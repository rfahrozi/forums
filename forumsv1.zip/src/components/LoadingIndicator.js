import React from 'react';
import './LoadingIndicator.css'; // Assuming we add CSS for skeleton

export default function LoadingIndicator() {
  return (
    <div className="skeleton-loader">
      <div className="skeleton-item" />
      <div className="skeleton-item" />
      <div className="skeleton-item" />
    </div>
  );
}
